# javaScript Projects - Curso em vídeo && Google

Projetos simples feitos em curso de JavaScript (básico ao intermediário)


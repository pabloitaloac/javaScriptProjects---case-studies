let tst = []

console.log(`o vetor teste é: ${tst}`)


tst[0] = 1
tst[1] = 32
tst[2] = 42
tst[3] = 2


console.log(`o vetor teste é: [${tst}]`)



tst[0] = 999
console.log(`o vetor teste é: [${tst}]`)
